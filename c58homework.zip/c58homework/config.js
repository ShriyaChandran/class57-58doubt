import firebase from 'firebase'
 var firebaseConfig = {
    apiKey: "AIzaSyCdRSL5yukKCY7lxnx3xa-6UK0K4SptNPM",
    authDomain: "newsletter-daef7.firebaseapp.com",
    databaseURL: "https://newsletter-daef7.firebaseio.com",
    projectId: "newsletter-daef7",
    storageBucket: "newsletter-daef7.appspot.com",
    messagingSenderId: "898967820148",
    appId: "1:898967820148:web:6a66736d8a68ef06a13e21"
  };
  firebase.initializeApp(firebaseConfig);
  export default firebase.database()