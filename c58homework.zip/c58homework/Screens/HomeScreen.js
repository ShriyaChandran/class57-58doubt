import * as React from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Image} from 'react-native';
import AppHeader from '../components/AppHeader'

export default class HomeScreen extends React.Component{
  goToHoroscope=()=>{
    this.props.navigation.navigate('Horoscope')
  }
  goTojoke=()=>{
    this.props.navigation.navigate('joke')
  }
  goToNews=()=>{
    this.props.navigation.navigate('News')
  }
  goToWeather=()=>{
    this.props.navigation.navigate('weather')
  }
  render(){
    return(
      <View>
        <AppHeader/>
        <TouchableOpacity style={styles.buttonStyle} onPress={this.goToHoroscope}>
        <Text style={styles.textStyle}> Horoscope</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.buttonStyle} onPress={this.goTojoke}>
        <Text style={styles.textStyle}> Joke </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.buttonStyle} onPress={this.goToNews}>
        <Text style={styles.textStyle}> News </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.buttonStyle} onPress={this.goToWeather}>
        <Text style={styles.textStyle}> Weather </Text>
        </TouchableOpacity>
      </View>
    )
  }
}

 const styles = StyleSheet.create({
  buttonStyle:{
    justifyContent:"Center",
    alignSelf:"Center",
    borderWidth:2,
    borderColor:"pink",
    borderRadius:25,
    marginTop:20,
    width:200,
    height:50,
    backgroundColor:"indigo"
  },
  textStyle:{
    textAlign:"center",
    color:"white"
  }
})
// isLikePressed(){

// }