import * as React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import SoundButton from '../components/SoundButton'
import AppHeader from '../components/AppHeader'

export default class Weather extends React.Component {
  render() {
    return (
      <View>
        
      </View>
    );
  }
}